package com.demo.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class CandidateDetails {

	
	@Id
	@GeneratedValue
	private int id;
	private String selected;
	private String reject;
	private String candidateName;
	@OneToOne
	private EmployeeDetails candId;
	@OneToMany
	private List<Skill> skill;
	private String level;
	private String interviewerName;
	private String interviewerId;
	private String date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSelected() {
		return selected;
	}
	public void setSelected(String selected) {
		this.selected = selected;
	}
	public String getReject() {
		return reject;
	}
	public void setReject(String reject) {
		this.reject = reject;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	
	public EmployeeDetails getCandId() {
		return candId;
	}
	public void setCandId(EmployeeDetails candId) {
		this.candId = candId;
	}
	
	public List<Skill> getSkill() {
		return skill;
	}
	public void setSkill(List<Skill> skill) {
		this.skill = skill;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getInterviewerName() {
		return interviewerName;
	}
	public void setInterviewerName(String interviewerName) {
		this.interviewerName = interviewerName;
	}
	public String getInterviewerId() {
		return interviewerId;
	}
	public void setInterviewerId(String interviewerId) {
		this.interviewerId = interviewerId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "CandidateDetails [id=" + id + ", selected=" + selected + ", reject=" + reject + ", candidateName="
				+ candidateName + ", candId=" + candId + ", skill=" + skill + ", level=" + level + ", interviewerName="
				+ interviewerName + ", interviewerId=" + interviewerId + ", date=" + date + "]";
	}
	
	
}