package com.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.CandidateDetails;
import com.demo.entity.EmpDetails;
import com.demo.entity.EmployeeDetails;
import com.demo.repo.CandidateRepo;
import com.demo.repo.EmpRepo;
import com.demo.repo.EmployeeRepo;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class EmployeeController {

	 @Autowired
	 EmployeeRepo repository;
	 
	 @Autowired
	 EmpRepo repo;
	 @Autowired
	 private CandidateRepo cRepo;
	 
	/*
	 * @Autowired skills skillrepo;
	 */
	 
	 @GetMapping("/employees")
	  public List<EmployeeDetails> getAllEmployeeDetails() {
	    System.out.println("Get all Employees...");
	 
	    List<EmployeeDetails> employees = new ArrayList<>();
	    repository.findAll().forEach(employees::add);
	 
	    return employees;
	  }
	 
	 @PostMapping("/employees/create")
	  public EmployeeDetails postEmployeeDetails(@RequestBody EmployeeDetails employee) {
		 employee.setBu("APPSEurope");
		EmployeeDetails _employee = repository.save(employee);
		CandidateDetails details=new CandidateDetails();
		details.setCandId(_employee);
		details.setCandidateName(_employee.getCandidateName());
		details.setDate(_employee.getIdate());
		details.setInterviewerId(_employee.getIempcode());
		details.setInterviewerName(_employee.getInterName());
//		details.setLevel(employee.get);
		details.setSkill(_employee.getSkill());
		System.out.println(details);
		cRepo.save(details);
	    return _employee;
	  }
	/*
	 * @GetMapping("/search") public String searchByName(@RequestParam String
	 * candidateName) { if( repository.findByCandidateName(candidateName)!= null)
	 * return "Present"; return "Not Present"; } //skills
	 * 
	 * @PostMapping("/skills") public Skill skill(@RequestBody Skill skill) { Skill
	 * _employee = skillrepo.save(skill); return _employee; }
	 */
	 
	 
	 @GetMapping("/employeesForm2")
	  public List<EmpDetails> getAllEmpDetails() {
	    System.out.println("Get all Employees...");
	 
	    List<EmpDetails> employees = new ArrayList<>();
	    repo.findAll().forEach(employees::add);
	 
	    return employees;
	  }
	 
	 @PostMapping("/employees/createForm2")
	  public EmpDetails postEmpDetails(@RequestBody EmpDetails employee) {
		employee.setBu("APPSEurope");
		 EmpDetails _employee = repo.save(employee);
	    return _employee;
	  }
	 @GetMapping("/get/{l1Id}")
	 public EmployeeDetails getEmpl(@PathVariable int l1Id) {
		return repository.findByL1Id(l1Id);
	 }
}
