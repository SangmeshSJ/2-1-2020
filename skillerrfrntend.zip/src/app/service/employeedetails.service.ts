import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Skill } from 'D:/Users/Default User/Downloads/feedback 13-12/frontend/src/app/model/skills'
@Injectable({
  providedIn: 'root'
})
export class EmployeedetailsService {

  private baseUrl = 'http://localhost:8000/api/';
  constructor(private http: HttpClient) { }

  getEmployeeDetails(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}get/${id}`);
  }
 
  createEmployeeDetails(employee: any): Observable<any> {
    return this.http.post(`${this.baseUrl}` + `employees/create`, employee);
  }

  getemployeeDetailsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `employees`);
  }

  createSkill(skills:any): Observable<any> {
    return this.http.post(`${this.baseUrl}` + `skills`, skills);
  };
// getSkills():Observable<any>{
//   return this.http.get<any>(`${this.baseUrl}` + `skill`);
//   // return this.http.get(this.baseUrl+'skill')
// }
};
