export class Skill{
    skillId: number;
    skillName:String;
}