export class EmpDetails{
    id:number;
    candidateName: String;
    idate: String;
    totalExp: String;
    releventExp: String;
    psdes1:String;
    bsdes1:String;
    odes1:String;
    cdes1:String;
    dtdes1:String;
    fdes1:String;
    ppdes1:String;
    mdes1:String;
    gdes1:String;
    rdes1:String;
    interName:String;
    hirecomment:String;
    rcomment:String;
    hcomment:String;
    iempcode:number;
    esign:String;
}