import { Mode } from './mode';
import {Skill } from './skills'
import { ITEMS} from './modeInt'
export class EmployeeDetails{
    id: number; 
    candidateName: String;
    idate: String;
    interName: String;
    totalExp: String;
    releventExp: String;
    skill:Skill[];
    mode:String;
    location:String;
    prating:String;
    crating:String;
    hirecomment:String;
    rcomment:String;
    hcomment:String;
    iempcode:number;
    esign:String;
    psdes1:String;
	bjdes2:String;
	kwdes:String;
	ta1:String;
    ta2:String;
    ta3:String;
    ides:String;
	cides:String;
	sdes:String;
    fdes:String;
    rating1:String;
    rating2:String;
    rating3:String;
    rating4:String;
    rating5:String;
    rating6:String
    rating7:String;
    rating8:String
    rating9:String;
    rating10:String
    levelOfInterviewer:String;

	

}